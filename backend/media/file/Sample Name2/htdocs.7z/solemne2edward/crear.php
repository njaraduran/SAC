
<?php
if (isset($_POST['submit'])) {
  $resultado = [
    'error' => false,
    'mensaje' => 'El Docente ' . $_POST['nombre'] . ' ha sido agregado con éxito' 
  ];
  $config = include 'config.php';

  try {
    $dsn = 'mysql:host=' . $config['db']['host'] . ';dbname=' . $config['db']['name'];
    $conexion = new PDO($dsn, $config['db']['user'], $config['db']['pass'], $config['db']['options']);

    $Docente = array(
      "nombre"   => $_POST['nombre'],
      "rut" => $_POST['rut'],
      "edad"    => $_POST['edad'],
      "direccion"    => $_POST['direccion'],
      "cursos"     => $_POST['cursos'],
    );
    
    $consultaSQL = "INSERT INTO Docente (nombre, rut, edad, direccion, cursos)";
    $consultaSQL .= "values (:" . implode(", :", array_keys($Docente)) . ")";
    
    $sentencia = $conexion->prepare($consultaSQL);
    $sentencia->execute($Docente);

  } catch(PDOException $error) {
    $resultado['error'] = true;
    $resultado['mensaje'] = $error->getMessage();
  }
}
?>

<?php include "templates/header.php"; ?>

<?php
if (isset($resultado)) {
  ?>
  <div class="container mt-3">
    <div class="row">
      <div class="col-md-12">
        <div class="alert alert-<?= $resultado['error'] ? 'danger' : 'success' ?>" role="alert">
          <?= $resultado['mensaje'] ?>
        </div>
      </div>
    </div>
  </div>
  <?php
}
?>

<?php include "templates/header.php"; ?>

<div class="container">
  <div class="row">
    <div class="col-md-12">
      <h2 class="mt-4">Ingresar Docentes</h2>
      <hr>
      <form method="post">
        <div class="form-group">
          <label for="nombre">Nombre</label>
          <input type="text" name="nombre" id="nombre" class="form-control">
        </div>
        <div class="form-group">
          <label for="rut">rut</label>
          <input type="text" name="rut" id="rut" class="form-control">
        </div>
        <div class="form-group">
          <label for="edad">edad</label>
          <input type="text" name="edad" id="edad" class="form-control">
        </div>
        <div class="form-group">
          <label for="direccion">direccion</label>
          <input type="text" name="edad" id="edad" class="form-control">
        </div>
        <div class="form-group">
          <label for="cursos">cursos</label>
          <input type="text" name="cursos" id="cursos" class="form-control">
        </div>
        <div class="form-group">
          <input type="submit" name="submit" class="btn btn-primary" value="Enviar">
          <a class="btn btn-primary" href="index.php">Regresar al inicio</a>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include "templates/footer.php"; ?>