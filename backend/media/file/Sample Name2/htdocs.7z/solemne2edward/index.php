<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="diseño/diseño.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UNAB PHP</title>
</head>
<body>
<?php include "templates/header.php"; ?>
    <header>
    <h1> PHP en la UNAB</h1>
    <nav>
        <ul>
            <li>
                <a href="#" class="inicio"> inicio</a>
            </li>
            <li>
                <a href="#" class="curso"> curso</a>
            </li>
            <li>
                <a href="#" class="profesores"> profesores</a>
            </li>
        </ul>
    </nav>
    </header>
    <p class="C1">
        Para poder conocer y aprender sobre PHP hay que recargar que se debe conocer por lo menos una base sobre HTML5 que es con el cual se trabaja muy amenudo.
        PHP es un lenguaje de programación y significa Hypertext Preprocessor. Es a través del lenguaje PHP, y otros lenguajes como el HTML, que podemos crear páginas web. El lenguaje PHP es de código abierto, lo que significa que se puede utilizar de forma gratuita, el cual (a diferencia de Javascript) es ejecutado en el servidor.
        De esta forma, el código es ejecutado en el servidor y el resultado enviado al navegador Web del cliente.

    </p>
    <img class="imgphp" src="https://programacion.net/files/article/20160118060140_php4.png" >
    
    <br class="T2"> ¿Que pasan en el curso?
    <p class="C2">
        En este curso se puede encontrar la enseñanza y practica desde cero de PHP, ademas de que se empieza a manipular no solo php, tambien incluye:

    </p>
    <div class="imghtml">
        <li>HTML:5
        <img src="https://th.bing.com/th/id/R.7eaf51b1efbac224a826255f61b1e827?rik=eRm41oxJPSkGKg&riu=http%3a%2f%2fwww.anerbarrena.com%2fwp-content%2fuploads%2f2016%2f04%2fhtml5.png&ehk=bJ70SG6NzRMeaPpGL%2fVzwhLOcnT0jiEkY%2bQQLeZFkHg%3d&risl=&pid=ImgRaw&r=0">
    
    </div>

    <div class="imgcss">
        <li>CSS
        <img src="https://th.bing.com/th/id/OIP.99KyaOlux4PFGX5q3a3CRQHaD4?pid=ImgDet&rs=1">
    
    </div>

    <div class="imgmysql">
        <li>MYSQL
        <img src="https://th.bing.com/th/id/R.69129ff3c06a69eef9928c8af2aefaec?rik=hoJWxO5UJ%2bKI5g&riu=http%3a%2f%2fpanamahitek.com%2fwp-content%2fuploads%2f2014%2f08%2fMySQL-Java.jpg&ehk=TmDAQYDl%2fvy7tg4pT37B2xlBUF7lIDnajLCAOqVNFN8%3d&risl=&pid=ImgRaw&r=0">
            
    </div>
    <p class="prof">Lista de Docentes</p>
    <a href="crear.php">Ingresar Docentes</a>

<?php
include 'funciones.php';

$error = false;
$config = include 'config.php';

try {
    $dsn = 'mysql:host=' . $config['db']['host'] . ';dbname=' . $config['db']['name'];
    $conexion = new PDO($dsn, $config['db']['user'], $config['db']['pass'], $config['db']['options']);
  
    $consultaSQL = "SELECT * FROM Docente";
  
    $sentencia = $conexion->prepare($consultaSQL);
    $sentencia->execute();
  
    $alumnos = $sentencia->fetchAll();
  
  } catch(PDOException $error) {
    $error= $error->getMessage();
  }
  ?>
  

<?php include "templates/footer.php"; ?>

</body>

</html>