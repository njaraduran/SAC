<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/decoracion.css"> 
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.min.js"></script> 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">  
        <title>Tópicos de Especialidad en Informática II</title> <!-- TÍTULO PÁGINA -->
    </head>
    <body>
        <!-- MAIN WRAPPER -->
        <div id="wrapper">
        <!-- BANNER WRAPPER -->
        <div id="banner-wrapper">
        <header>
            <div id="header-inner"> <!-- ENCABEZADO -->
                <a href="#" id="logo"> <!-- # ENLACE A MARCADORES  -->
                    <img src="img/pics/logounab.jfif" alt="" style="width:75px;height:75px;">
                </a>
                <nav> <!-- # SECCION DE NAVEGACION -->
                    <a href="#" id="menu-icon"> <!-- # ENLACE AL INICIO  -->
                        <i class="fa fa-bars"></i>
                    </a>
                    <ul>
                        <li>
                            <a href="index.php" class="current">
                                <!-- # ENLACE A LA PAGINA PRINCIPAL  -->
                                Inicio
                            </a>
                        </li>
                        <li>
                            <a href="#objetivos">
                                <!-- # ENLACE A OBJETIVOS -->
                                Objetivos
                            </a>
                        </li>
                        <li>
                            <a href="#curso">
                                <!-- # ENLACE A DEFINICIÓN DEL CURSO -->
                                Curso
                            </a>
                        </li>
                        <li>
                            <a href="#estudiantes">
                                <!-- # ENLACE A ESTUDIANTES -->
                                Estudiantes
                            </a>
                        </li>
                        <li>
                            <a href="#otros">
                                <!-- # ENLACE A OTROS -->
                                Otros
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </header>
        <!-- SLIDER -->
        <div id="slide-wrap">
            <section class="slider">
                <ul class="slider1">
                    <li><img src="img/slider/slider1.jpg" alt="" style="width:948px;height:497px;"></li>
                    <li><img src="img/slider/slider2.jpg" alt="" style="width:948px;height:497px;"></li>
                    <li><img src="img/slider/slider3.jfif" alt="" style="width:948px;height:497px;"></li>
                </ul>
            </section>
        </div>
    </div>
    <!-- ICONS -->
    <section class="one-third" id="objetivos">
        <div class="icon-wrap">
            <i class="fa fa-cog"></i> <!-- ICONO DE ENGRANAJE -->
        </div>
        <h3> Objetivo 1 </h3>
        <p>Explicar qúe es el curso de Tópicos y Especialidad en Informática II.</p>
    </section>
    <section class="one-third">
        <div class="icon-wrap">
            <i class="fa fa-list"></i> <!-- ICONO DE LISTA -->
        </div>
        <h3> Objetivo 2 </h3>
        <p>Mostrar lista de estudiantes del curso.</p>
    </section>
    <section class="one-third">
        <div class="icon-wrap">
            <i class="fa fa-pencil-square-o"></i> <!-- ÍCONO DE EDITAR -->
        </div>
        <h3>Objetivo 3</h3>
        <p>Realizar proceso de editar los estudiantes de la lista.</p>
    </section>
    
    <div class="clearfix-padding"></div>
    <!-- LEFT COL -->
    <section class="left-col" id="curso">
        <h3>Tópicos de Especialidad en Informática II</h3>
        <p>Tópicos de Especialidad en Informática II es un ramo que habla de conocimientos necesarios en cualquier destreza que uno busque especializarse en el area de la informática. Un ejemplo es hacer páginas web.</p>
    </section>
    <section class="sidebar">
        <img src="img/pics/especializacion.png">
    </section>
    <div class="clearfix-padding"></div>
    
    <table border="" id="estudiantes"> <!-- TABLA DE ESTUDIANTES -->
	<?php  
include 'funciones.php';

$error=false;
$config = include 'config.php';
try {
	$dsn = 'mysql:host='.$config['db']['host'].';dbname='.$config['db']['name'];
	$conexion = new PDO($dsn,$config['db']['user'],$config['db']['pass'],$config['db']['option']);
	$consultaSQL = "SELECT * FROM estudiantes";
	$sentencia = $conexion->prepare($consultaSQL);
	$sentencia->execute();
	$estudiantes = $sentencia->fetchAll();
} catch(PDOException $error){
	$error =$error->getMessage();
}
?>

<div class="container">
 <div class="row">
  <div class="col-md-12">
   <h2 class="mt-3">Lista de Estudiantes</h2>
   <table class="table">
   	<thead>
   	 <tr>
   	 	<th>Nombre</th>
		<th>Rut</th>
   	 	<th>Edad</th>
		<th>Dirección</th>
   	 	<th>Acciones</th>
   	 </tr>
   	</thead>
   	<tbody>
   		<?php  
   		if ($estudiantes && $sentencia->rowCount()>0){
   			foreach($estudiantes as $fila){
   			?>
   		 <tr>
   		 	<td><?php echo escapar($fila["nombre"]); ?></td>
			<td><?php echo escapar($fila["id"]); ?></td>
   		 	<td><?php echo escapar($fila["edad"]); ?></td>
			<td><?php echo escapar($fila["direccion"]); ?></td>
   		 	<td><a href="<?= 'borrar.php?id='.escapar($fila["id"]) ?>">🗑️Borrar</a>
   		 		<a href="<?= 'editar.php?id='.escapar($fila["id"]) ?>">✏️Editar</a></td>
   		 </tr>
   		 <?php 
   			}
   		}
   		?>
   	</tbody>
	</table>
	</div>
	</div>
</div>
<?php include 'templates/header.php'; ?>
<div class="container">
 <div class="row">
  <div class="col-md-12">
  	<a href="crear.php" class="btn btn-primary mt-4">Crear Estudiante</a>
  	<hr>
  </div>
</div>
</div>

<?php include 'templates/footer.php'; ?>
    <!-- FOOTER -->
    <footer>
        <div class="banner-wrapper" id="otros">
            <div class="icon-text">
                <div class="icon-text-icon">
                    <ul class="footer-nav">
                        <li>
                            <a href="index.php">Inicio</a>
                        </li>
                        <li>
                            <a href="index.php#objetivos">Objetivos</a>
                        </li>
                        <li>
                            <a href="index.php#curso">Curso</a>
                        </li>
                        <li>
                            <a href="index.php#estudiantes">Estudiantes</a>
                        </li>
                        <li>
                            <a href="index.php#otros">Otros</a>
                        </li>
                    </ul>
                </div>
                <div class="icon-text-text">
                    <ul class="social">
                        <li>
                            <a href="https://www.facebook.com/unab.cl">
                                <i class="fa fa-facebook"></i>
                            </a>
                        </li>
                        <li>
                            <a href="https://twitter.com/uandresbello">
                                <i class="fa fa-twitter"></i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.youtube.com/c/unabtv">
                                <i class="fa fa-youtube"></i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/unaboficial">
                                <i class="fa fa-instagram"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    <div class="clearfix-padding"></div>

    <!-- SCRIPTS -->
    <script>
    $(document).ready(function(){
        $('.slider1').bxSlider({
            mode: 'fade',
        });
        $('.slider2').bxSlider({
            mode: 'fade',
        });
        $('.slider3').bxSlider({
            mode: 'fade',
        });
    });
    </script>
    </body>
</html>