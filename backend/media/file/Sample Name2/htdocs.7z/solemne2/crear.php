<?php 
if (isset($_POST['submit'])){
	$resultado =[
		'error' =>false,
		'mensaje'=>'El estudiante '.$_POST['nombre'].' ha sido creado con éxito'
	];
	$config = include 'config.php';
	try {
		$dsn = 'mysql:host='.$config['db']['host'].';dbname='.$config['db']['name'];
		$conexion = new PDO($dsn,$config['db']['user'],$config['db']['pass'],$config['db']['option']);
		$estudiante = [
			"nombre" => $_POST['nombre'],
			"id" => $_POST['id'],
			"edad" => $_POST['edad'],
			"direccion" => $_POST['direccion'],
		];
		$consultaSQL = "INSERT INTO estudiantes (nombre,id,edad,direccion)";
		$consultaSQL .= "values (:".implode(", :", array_keys($estudiante)).")";
		$sentencia = $conexion->prepare($consultaSQL);
		$sentencia->execute($estudiante);
	} 
	catch(PDOException $error){
		$resultado['error']=true;
		$resultado['mensaje']=$error->getMessage();
	}
}
?>

<?php include "templates/header.php"; ?>
<?php  
if (isset($resultado)){
	?>
	<div class="container">
 	 <div class="row">
  	  <div class="col-md-12">
  	   <div class="alert alert-<?= $resultado['error'] ? ' danger' : 'success' ?> " role="alert">
  	   		<?= $resultado['mensaje'] ?>
  	   	</div>
  	   </div>
  	</div>
  </div>
  <?php
}
?>

<div class="container">
 <div class="row">
  <div class="col-md-12">
  	<h2 class="mt-4">Crear Estudiante</h2>
  	<hr>
  	<form method="post">
  	 <div class="form-group">
  	  <label for="nombre">Nombre</label>
  	  <input type="text" name="nombre" id="nombre" class="form-control">
  	 </div>
  	 <div class="form-group">
  	  <label for="id">Rut</label>
  	  <input type="text" name="id" id="id" class="form-control">
  	 </div>
  	 <div class="form-group">
  	  <label for="edad">Edad</label>
  	  <input type="text" name="edad" id="edad" class="form-control">
  	 </div>
	<div class="form-group">
		<label for="direccion">Dirección</label>
		<input type="text" name="direccion" id="direccion" class="form-control">
	</div>
  	 <div class="form-group">
  	  <input type="submit" name="submit" class="btn btn-primary" value="Enviar">
  	  <a class="btn btn-primary" href="index.php">Regresar al Inicio</a>
  	 </div>
  	</form>
  </div>
</div>
</div>
<?php include "templates/footer.php"; ?>